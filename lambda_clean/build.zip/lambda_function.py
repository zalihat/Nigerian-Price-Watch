import clean_data

def lambda_handler(event, context):
    return clean_data.main(event)